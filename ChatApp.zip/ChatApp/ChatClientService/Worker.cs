using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ChatCommon;

namespace ChatClientService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private TcpClient _client;

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _client = new TcpClient();
            await _client.ConnectAsync(ChatConstants.ServerIp, ChatConstants.ServerPort);
            _logger.LogInformation("Connected to server.");

            var stream = _client.GetStream();
            var reader = new StreamReader(stream, Encoding.UTF8);
            var writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

            // Set username
            Console.WriteLine(await reader.ReadLineAsync());
            string username = Console.ReadLine();
            await writer.WriteLineAsync(username);

            // Start a task to listen for messages
            _ = Task.Run(() => ListenForMessages(reader), stoppingToken);

            // Send messages
            while (!stoppingToken.IsCancellationRequested)
            {
                Console.WriteLine("Enter recipient:");
                string recipient = Console.ReadLine();
                Console.WriteLine("Enter message:");
                string content = Console.ReadLine();

                var message = new Message
                {
                    Sender = username,
                    Recipient = recipient,
                    Content = content
                };

                string messageJson = System.Text.Json.JsonSerializer.Serialize(message);
                _logger.LogInformation("Sending message: {Sender} -> {Recipient}: {Content}", message.Sender, message.Recipient, message.Content);
                await writer.WriteLineAsync(messageJson);
            }
        }
        private async Task ListenForMessages(StreamReader reader)
        {
            while (true)
            {
                try
                {
                    string messageJson = await reader.ReadLineAsync();
                    if (!string.IsNullOrEmpty(messageJson))
                    {
                        var message = System.Text.Json.JsonSerializer.Deserialize<Message>(messageJson);
                        if (message != null)
                        {
                            _logger.LogInformation("Received message from {Sender}: {Content}", message.Sender, message.Content);
                            Console.WriteLine($"{message?.Sender}: {message?.Content}");
                        }
                        else
                        {
                            _logger.LogWarning("Failed to deserialize message: {MessageJson}", messageJson);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError("Error while listening for messages: {0}", ex.Message);
                }
            }
        }



        public override Task StopAsync(CancellationToken stoppingToken)
        {
            _client?.Close();
            return base.StopAsync(stoppingToken);
        }
    }
}
