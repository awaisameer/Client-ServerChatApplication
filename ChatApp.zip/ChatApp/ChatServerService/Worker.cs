using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ChatCommon;

namespace ChatServerService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private TcpListener _server;
        private readonly Dictionary<string, TcpClient> _activeUsers = new();

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _server = new TcpListener(IPAddress.Parse(ChatConstants.ServerIp), ChatConstants.ServerPort);
            _server.Start();
            _logger.LogInformation("Server started at {IP}:{Port}", ChatConstants.ServerIp, ChatConstants.ServerPort);

            while (!stoppingToken.IsCancellationRequested)
            {
                TcpClient client = await _server.AcceptTcpClientAsync(); // Wait for a new client
                _logger.LogInformation("New client connected.");

                // Handle the client in a separate thread
                _ = Task.Run(() => HandleClient(client));
            }
        }
        private async Task HandleClient(TcpClient client)
        {
            using (var stream = client.GetStream())
            using (var reader = new StreamReader(stream, Encoding.UTF8))  // Reader still reads UTF-8 correctly
            using (var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true })  // No BOM
            {
                // Ask for the username
                await writer.WriteLineAsync("Enter your username:");
                string username = await reader.ReadLineAsync();
                if (string.IsNullOrEmpty(username)) return;

                // Add user to the active users
                lock (_activeUsers)
                {
                    _activeUsers[username] = client;
                }
                _logger.LogInformation("{Username} connected.", username);

                // Keep listening for messages from this client
                while (true)
                {
                    try
                    {
                        string messageJson = await reader.ReadLineAsync();
                        if (string.IsNullOrEmpty(messageJson)) break;

                        var message = System.Text.Json.JsonSerializer.Deserialize<Message>(messageJson);
                        _logger.LogInformation("Received message from {Sender} to {Recipient}: {Content}", message?.Sender, message?.Recipient, message?.Content);

                        if (message != null && _activeUsers.TryGetValue(message.Recipient, out var recipientClient))
                        {
                            var recipientStream = recipientClient.GetStream();
                            var recipientWriter = new StreamWriter(recipientStream, new UTF8Encoding(false)) { AutoFlush = true };
                            await recipientWriter.WriteLineAsync(messageJson); // Send message to the recipient
                            _logger.LogInformation("Message forwarded to {Recipient}.", message?.Recipient);
                        }
                        else
                        {
                            await writer.WriteLineAsync("Recipient not available.");
                            _logger.LogWarning("Message failed: Recipient {Recipient} not found.", message?.Recipient);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Error handling client: {0}", ex.Message);
                        break;
                    }
                }

                // Remove user when they disconnect
                lock (_activeUsers)
                {
                    _activeUsers.Remove(username);
                }
                _logger.LogInformation("{Username} disconnected.", username);
            }
        }



        public override Task StopAsync(CancellationToken stoppingToken)
        {
            _server?.Stop();
            return base.StopAsync(stoppingToken);
        }
    }
}
